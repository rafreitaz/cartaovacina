package com.piuna.CartaoVacinaOnline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartaoVacinaOnlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartaoVacinaOnlineApplication.class, args);
	}
}
